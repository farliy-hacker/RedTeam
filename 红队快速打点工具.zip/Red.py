import requests
import json
import base64
import csv
import sys
import os
import argparse

#这里是奇安信的鹰图配置
hunter_key = ""

#这里是00信安的配置
site_api = ''
results_pwd = 'Red.txt'
#下面是FOFA的配置
email = r''
api_key = r''
api = r'https://fofa.info/api/v1/search/all?email={}&key={}&qbase64={}&size=10000'



def run_site(page):
    global site_api,site_keyword
    postdata = {"title":site_keyword,"title_type":"site","page":page,"pagesize":40,"zone_key_id":site_api}
    headers = {'Content-Type':'application/json'}
    response = requests.post(url="https://0.zone/api/data/",timeout=5,headers=headers,data=json.dumps(postdata))
    try:
        rejson = json.loads(response.text)['data']
    except Exception as _:
        print("已没有更多结果，结束")
        print("进入Web指纹识别模块..........")
        os.system("python Finger.py -f Red.txt")
        print("进入POC漏洞扫描模块..........")
        os.system("python pocbomber.py -f Red.txt -o POC漏洞扫描报告.txt ")
        sys.exit()
    return (rejson)

def run_site_fofa(fofa_keyword):
    global email , api_key,api,results_pwd
    flag = base64.b64encode(fofa_keyword.encode()).decode()
    response = requests.get(api.format(email, api_key, flag))
    results = response.json()["results"]
    print("FOFA中共搜索到{}条记录！".format(len(results)))
    file_name = results_pwd
    f = open(file_name, "a")
    for addr in results:
        f.write(addr[0] + '\n')
        print("FOFA爬取中:", addr)
    f.close()

def run_site_hunter(hunter_keyword):
    global hunter_key,results_pwd
    hun_base64 = base64.b64encode(hunter_keyword.encode()).decode()
    url = "https://hunter.qianxin.com/openApi/search?api-key={}&search={}&page=1&page_size=10&is_web=3&status_code=200&start_time=2022-06-19+00%3A00%3A00&end_time=2022-07-18+23%3A59%3A59".format(
        hunter_key, hun_base64)
    file_name = results_pwd
    r = requests.get(url)
    json_data = r.json()
    url_list = [arr['url'] for arr in json_data['data']['arr']]
    print("奇安信鹰图爬取URL:", url_list)
    with open(file_name, "a", encoding='utf-8') as f:
        f.write("\n".join(url_list))

def main():
    run_site_fofa(fofa_keyword)
    run_site_hunter(hunter_keyword)
    ii = 0
    while 1:
        ii =ii+1
        rejson = run_site(ii)
        for i in rejson:
            #ip = i['ip']
            #port = i['port']
            url = i['url']
            write_csv_b(url)


def write_csv_b(url):
    global results_pwd
    f = open(results_pwd, 'a+', encoding='GBK', newline='')
    try:
        csv_writer = csv.writer(f)
        csv_writer.writerow([url])
        print("00信安爬取中:",url)
    finally:
        f.close()

if __name__ == "__main__":
    if(len(sys.argv) < 2):
        print("|-----------------------------------------------------------------------------------|")
        print("|                                site_api 改为你的API KEY和FOFA的配置                             |")
        print("|                       使用方法: python3 Red.py  广东工贸职业技术学院  domain='gdgm.cn' web.body='H3C'")
        print("|                       results_pwd 是结果文件存储路径                               |")
        print("|                                [!] [!] [!]                                        |")
        print("|___________________________________________________________________________________|")
        sys.exit()
    target = sys.argv[1]
    if(target == '-h' or target == "--help" or target == "-help"):
        print("使用方法: python3 Red.py  广东工贸职业技术学院  domain='gdgm.cn' web.body='H3C'")
    targets = sys.argv[2]
    hunter_target = sys.argv[3]
    site_keyword = target
    fofa_keyword = targets
    hunter_keyword = hunter_target
    main()

