#!/usr/bin/env python
# -*- coding: utf-8 -*-
# author = EASY
from config.datatype import AttribDict
from config.log import MY_LOGGER

logging  = MY_LOGGER

path = AttribDict()
Urls = AttribDict()
Ips = AttribDict()
Webinfo = AttribDict()
Save = AttribDict()
Urlerror = AttribDict()
