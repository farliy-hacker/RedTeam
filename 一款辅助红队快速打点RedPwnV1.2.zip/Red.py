import requests
import json
import base64
import csv
import socket
import sys
import os
import time
import threading
from POC.Apache_Hadoop_Yarn_RPC_RCE import *
from POC.CVE_2020_25078 import *
from POC.CVE_2022_22954 import *
from POC.CVE_2022_23337 import *
from POC.CVE_2022_29464 import *
from POC.CVE_2022_8515 import *
#在这里增加POC模块!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


#这里是奇安信的鹰图配置
hunter_key = ""

#这里是00信安的配置
site_api = ''
results_pwd = 'Red.txt'
#下面是FOFA的配置
email = r''
api_key = r''
api = r'https://fofa.info/api/v1/search/all?email={}&key={}&qbase64={}&size=10000'



def run_site(page):
    global site_api,site_keyword
    postdata = {"title":site_keyword,"title_type":"site","page":page,"pagesize":40,"zone_key_id":site_api}
    headers = {'Content-Type':'application/json',
               'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/110.0',
               'Connection': 'close'
               }
    response = requests.post(url="https://0.zone/api/data/",timeout=5,headers=headers,data=json.dumps(postdata))
    try:
        rejson = json.loads(response.text)['data']
    except Exception as _:
        print("已没有更多结果，结束")
        time.sleep(1)
        print("开始进入批量网站200存活检测模块........................................................")
        print("若出现Warning字样是正常现象!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
        with open("Red.txt", "r") as f:
            for ip in f:
                hack_ip = ip.strip("\n")
                if hack_ip[:7] == 'http://' or hack_ip[:8] == 'https://':
                    time.sleep(0.3)
                    try:
                        response = requests.get(url=hack_ip, timeout=7, headers=headers, verify=False)
                        if response.status_code == 200:
                            with open("修正后获得200状态码的网站.txt", "a") as file:
                                file.write(hack_ip + "\n")
                                file.close()
                        else:
                            pass
                    except Exception as e:
                        print("有个请求出现异常,跳过并继续处理.................................................")
                        pass
                else:
                    newurl = 'http://' + str(hack_ip)
                    time.sleep(0.3)
                    try:
                        response = requests.get(url=newurl, timeout=7, headers=headers, verify=False)
                        if response.status_code == 200:
                            with open("修正后获得200状态码的网站.txt", "a") as file:
                                file.write(newurl + "\n")
                                file.close()
                        else:
                            pass
                    except Exception as e:
                        print("有个请求出现异常,跳过并继续处理.................................................")
                        pass
        f.close()
        os.remove('Red.txt')
        domain = open("修正后获得200状态码的网站.txt","r")
        # 判断CDN
        for domains in domain:
            domains = domains.strip("\n")
            if domains[:7] == "http://":
                sss = domains.strip("http://")
                ip_list = []
                number = 0
                try:
                    addrs = socket.getaddrinfo(sss, 'http')
                    for item in addrs:
                        # print(item)
                        if item[4][0] not in ip_list:
                            ip_list.append(item[4][0])
                            number += 1
                except Exception as e:
                    pass
                    print("已经去掉无法处理的..............................")
                if number > 1:  # getaddrinfo的返回结果中，多于一个ip，即存在cdn
                    print('存在cdn', sss)
                    with open("存在CDN的网站.txt","a") as dfan:
                        dfan.write(sss+"\n")
                    dfan.close()
            elif domains[:8] == "https://":
                sss = domains.strip("https://")
                ip_list = []
                number = 0
                try:
                    addrs = socket.getaddrinfo(sss, 'http')
                    for item in addrs:
                        # print(item)
                        if item[4][0] not in ip_list:
                            ip_list.append(item[4][0])
                            number += 1
                except Exception as e:
                    pass
                    print("已经去掉无法处理的..............................")
                if number > 1:  # getaddrinfo的返回结果中，多于一个ip，即存在cdn
                    print('存在cdn', sss)
                    with open("存在CDN的网站.txt","a") as dfan:
                        dfan.write(sss+"\n")
                    dfan.close()
        domain.close()
        time.sleep(0.1)
        print("进入Web指纹识别模块..........")
        os.system("python Finger.py -f 修正后获得200状态码的网站.txt")
        print("进入自己的POC漏洞扫描模块(支持编写导入)..........")
        time.sleep(0.5)
        domain_Hello = open("修正后获得200状态码的网站.txt", "r")
        for domains_Hello in domain_Hello:
            domainss = domains_Hello.strip("\n")
            #####################################
            ###在这里添加你的POC-def函数,从而调用POC
            Apache_Hadoop_Yarn_RPC_RCE_POC(domainss)
            time.sleep(0.1)
            dcs_admin_passwd_leak_poc(domainss)
            time.sleep(0.1)
            vmware_one_access_ssti_poc(domainss)
            time.sleep(0.1)
            dede_sql_poc(domainss)
            time.sleep(0.1)
            CVE_2022_29464_exp(domainss)
            time.sleep(0.1)
            vigor_rce_poc(domainss)
        domain_Hello.close()
        time.sleep(0.3)
        print("进入自动化POCbomber漏洞检测")
        os.system("python pocbomber.py -f 修正后获得200状态码的网站.txt -o POC漏洞扫描报告.txt ")
        sys.exit()
    return (rejson)

def run_site_fofa(fofa_keyword):
    global email , api_key,api,results_pwd
    flag = base64.b64encode(fofa_keyword.encode()).decode()
    response = requests.get(api.format(email, api_key, flag))
    results = response.json()["results"]
    print("FOFA中共搜索到{}条记录！".format(len(results)))
    file_name = results_pwd
    f = open(file_name, "a")
    for addr in results:
        f.write(addr[0] + '\n')
        print("FOFA爬取中:", addr)
    f.close()

def run_site_hunter(hunter_keyword):
    global hunter_key,results_pwd
    hun_base64 = base64.b64encode(hunter_keyword.encode()).decode()
    url = "https://hunter.qianxin.com/openApi/search?api-key={}&search={}&page=1&page_size=10&is_web=3&status_code=200&start_time=2022-06-19+00%3A00%3A00&end_time=2022-07-18+23%3A59%3A59".format(
        hunter_key, hun_base64)
    file_name = results_pwd
    r = requests.get(url)
    json_data = r.json()
    url_list = [arr['url'] for arr in json_data['data']['arr']]
    print("奇安信鹰图爬取URL:", url_list)
    with open(file_name, "a", encoding='utf-8') as f:
        f.write("\n".join(url_list))

def main():
    run_site_fofa(fofa_keyword)
    run_site_hunter(hunter_keyword)
    ii = 0
    while 1:
        ii =ii+1
        rejson = run_site(ii)
        for i in rejson:
            #ip = i['ip']
            #port = i['port']
            url = i['url']
            write_csv_b(url)


def write_csv_b(url):
    global results_pwd
    f = open(results_pwd, 'a+', encoding='GBK', newline='')
    try:
        csv_writer = csv.writer(f)
        csv_writer.writerow([url])
        print("00信安爬取中:",url)
        time.sleep(0.1)
    finally:
        f.close()

if __name__ == "__main__":
    if(len(sys.argv) < 2):
        print("|-----------------------------------------------------------------------------------|")
        print("|                                site_api 改为你的API KEY和FOFA的配置                             |")
        print("|                       使用方法: python3 Red.py  广东工贸职业技术学院  domain='gdgm.cn' web.body='H3C'")
        print("|                       results_pwd 是结果文件存储路径                               |")
        print("|                                [!] [!] [!]                                        |")
        print("|___________________________________________________________________________________|")
        sys.exit()
    target = sys.argv[1]
    if(target == '-h' or target == "--help" or target == "-help"):
        print("使用方法: python3 Red.py  广东工贸职业技术学院  domain='gdgm.cn' web.body='H3C'")
    targets = sys.argv[2]
    hunter_target = sys.argv[3]
    site_keyword = target
    fofa_keyword = targets
    hunter_keyword = hunter_target
    #多线程处理main函数
    t1 = threading.Thread(target=main)
    t1.start()


